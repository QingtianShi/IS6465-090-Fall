<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="AirAsia Rewards gift card catalog — a student HTML and CSS prototype.">
  <title>Gift card details | AirAsia Rewards</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header"><div class="header-inner"><a class="brand" href="card-list.php" aria-label="AirAsia Rewards home"><span>airasia</span><b>rewards</b></a><nav aria-label="Main navigation"><a class="nav-link" href="card-list.php">Gift cards</a><a class="nav-link" href="card-add.php">Add a card</a><a class="logout" href="login.php">Log out ↗</a></nav></div></header>
<main id="main"><a class="back" href="card-list.php">← Back to gift cards</a><div class="detail-layout"><section class="detail-art"><img src="images/flight.svg" alt="AirAsia Flight gift card worth $100"><p>A little further. A little more adventure.</p></section><section class="detail-content"><p class="eyebrow">TRAVEL GIFT CARD</p><h1>AirAsia Flight<br>Gift Card</h1><p class="muted">Turn your points into your next getaway with a flight gift card.</p><dl><div><dt>Card name</dt><dd>AirAsia Flight Gift Card</dd></div><div><dt>Card type</dt><dd>Travel</dd></div><div><dt>Card value</dt><dd>$100.00 USD</dd></div><div><dt>Points required</dt><dd class="points">10,000 points</dd></div></dl><a class="button" href="card-update.php">Update gift card <span aria-hidden="true">→</span></a></section></div></main>
<footer><span>AirAsia Rewards · HW2</span><span>Student prototype · Sample gift cards</span></footer>
</body>
</html>
