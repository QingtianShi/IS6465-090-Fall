<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="AirAsia Rewards gift card catalog — a student HTML and CSS prototype.">
  <title>Update gift card | AirAsia Rewards</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header"><div class="header-inner"><a class="brand" href="card-list.php" aria-label="AirAsia Rewards home"><span>airasia</span><b>rewards</b></a><nav aria-label="Main navigation"><a class="nav-link" href="card-list.php">Gift cards</a><a class="nav-link" href="card-add.php">Add a card</a><a class="logout" href="login.php">Log out ↗</a></nav></div></header>
<main id="main"><a class="back" href="card-details.php">← Back to details</a><section class="form-layout"><div class="form-intro"><p class="eyebrow">MANAGE YOUR COLLECTION</p><h1>Update a gift card.</h1><p class="muted">Review the existing details and make your changes below.</p><div class="aside-note"><span>01 / CARD DETAILS</span><p>Give each reward a clear name, category, value, and points requirement.</p></div></div><div class="form-panel"><h2>Card information</h2><p class="muted small">All fields are required. Values are in USD.</p><form action="card-list.php" method="get"><div class="field"><label for="card-name">Card Name</label><input id="card-name" name="card-name" type="text" value="AirAsia Flight Gift Card" required maxlength="100"></div><div class="field"><label for="card-type">Card Type</label><select id="card-type" name="card-type" required><option value="Travel" selected>Travel</option><option value="Hotel">Hotel</option><option value="Dining">Dining</option><option value="Shopping">Shopping</option></select></div><div class="field-row"><div class="field"><label for="card-value">Card Value (USD)</label><input id="card-value" name="card-value" type="number" min="0.01" step="0.01" value="100.00" required></div><div class="field"><label for="points">Points Required</label><input id="points" name="points" type="number" min="1" step="1" value="10000" required></div></div><div class="form-actions"><button class="button" type="submit">Save changes <span aria-hidden="true">→</span></button><a class="cancel" href="card-list.php">Cancel</a></div><p class="note">This is a static prototype. Submitting returns to the catalog; changes are not saved.</p></form></div></section></main>
<footer><span>AirAsia Rewards · HW2</span><span>Student prototype · Sample gift cards</span></footer>
</body>
</html>
