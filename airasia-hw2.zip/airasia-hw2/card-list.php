<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="AirAsia Rewards gift card catalog — a student HTML and CSS prototype.">
  <title>Gift cards | AirAsia Rewards</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header"><div class="header-inner"><a class="brand" href="card-list.php" aria-label="AirAsia Rewards home"><span>airasia</span><b>rewards</b></a><nav aria-label="Main navigation"><a class="nav-link" href="card-list.php">Gift cards</a><a class="nav-link" href="card-add.php">Add a card</a><a class="logout" href="login.php">Log out ↗</a></nav></div></header>
<main id="main"><section class="page-heading"><div><p class="eyebrow">THE REWARDS COLLECTION</p><h1>More moments. More rewards.</h1><p class="muted">Discover a little something to look forward to.</p></div><a class="button" href="card-add.php">＋ Add gift card</a></section><section aria-label="Gift card catalog"><div class="section-label"><h2>Explore gift cards</h2><span>3 gift cards</span></div><div class="card-grid"><article class="gift-card"><a href="card-details.php" aria-label="View gift card details for AirAsia Flight"><img src="images/flight.svg" alt="AirAsia Flight gift card worth $100"></a><div class="card-body"><span class="category">Travel</span><h2><a href="card-details.php">AirAsia Flight Gift Card</a></h2><p class="muted">$100.00 gift card value</p><div class="card-bottom"><p><strong>10,000</strong> <span>points</span></p><a class="round-link" href="card-details.php" aria-label="View AirAsia Flight gift card details">↗</a></div></div></article><article class="gift-card"><a href="card-details.php" aria-label="View gift card details for AirAsia Hotel"><img src="images/hotel.svg" alt="AirAsia Hotel gift card worth $75"></a><div class="card-body"><span class="category">Hotel</span><h2><a href="card-details.php">AirAsia Hotel Gift Card</a></h2><p class="muted">$75.00 gift card value</p><div class="card-bottom"><p><strong>7,500</strong> <span>points</span></p><a class="round-link" href="card-details.php" aria-label="View AirAsia Hotel gift card details">↗</a></div></div></article><article class="gift-card"><a href="card-details.php" aria-label="View gift card details for AirAsia Dining"><img src="images/dining.svg" alt="AirAsia Dining gift card worth $25"></a><div class="card-body"><span class="category">Dining</span><h2><a href="card-details.php">AirAsia Dining Gift Card</a></h2><p class="muted">$25.00 gift card value</p><div class="card-bottom"><p><strong>2,500</strong> <span>points</span></p><a class="round-link" href="card-details.php" aria-label="View AirAsia Dining gift card details">↗</a></div></div></article></div><p class="note">Sample catalog: all cards open the same Flight gift card details page for this prototype.</p></section></main>
<footer><span>AirAsia Rewards · HW2</span><span>Student prototype · Sample gift cards</span></footer>
</body>
</html>
