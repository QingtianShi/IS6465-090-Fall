<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="AirAsia Rewards gift card catalog — a student HTML and CSS prototype.">
  <title>Log in | AirAsia Rewards</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header"><div class="header-inner"><a class="brand" href="login.php" aria-label="AirAsia Rewards home"><span>airasia</span><b>rewards</b></a></div></header>
<main id="main"><div class="login-layout"><section class="welcome"><p class="eyebrow">SMALL REWARDS. BIG POSSIBILITIES.</p><h1>Your next<br>great moment<br>starts here.</h1><p>Explore gift cards for your next getaway,<br>your next stay, or your next favorite meal.</p><img src="images/flight.svg" alt="AirAsia Flight gift card worth $100"></section><section class="login-panel"><p class="eyebrow">AIRASIA REWARDS</p><h2>Welcome back.</h2><p class="muted">Log in to explore the gift card catalog.</p><form action="card-list.php" method="get"><div class="field"><label for="username">Username</label><input id="username" type="text" autocomplete="username" placeholder="Enter your username" required></div><div class="field"><label for="password">Password</label><input id="password" type="password" autocomplete="current-password" placeholder="Enter your password" required></div><button class="button full" type="submit">Login <span aria-hidden="true">→</span></button></form><p class="note">Demo login: enter any sample username and password. No account is required.</p></section></div></main>
<footer><span>AirAsia Rewards · HW2</span><span>Student prototype · Sample gift cards</span></footer>
</body>
</html>
